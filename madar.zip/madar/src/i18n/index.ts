import { EVENTS } from '../data/events.ts';
import en from './en.ts';
import ar from './ar.ts';
import evEn from './events.en.ts';
import evAr from './events.ar.ts';
export type Lang = 'en' | 'ar';
// Event text is written compactly as [title, body, choice1, choice2] and expanded into ev.<id>.t / .b / .<choiceId> keys.
const expand = (txt: Record<string, string[]>) => {
  const o: Record<string, string> = {};
  for (const e of EVENTS) {
    const a = txt[e.id]; if (!a) continue;
    o[`ev.${e.id}.t`] = a[0]; o[`ev.${e.id}.b`] = a[1];
    e.choices.forEach((c, i) => { if (a[2 + i]) o[`ev.${e.id}.${c.id}`] = a[2 + i]; });
  }
  return o;
};
export const D: Record<Lang, Record<string, string>> = { en: { ...en, ...expand(evEn) }, ar: { ...ar, ...expand(evAr) } };
export const t = (l: Lang, k: string, p?: Record<string, string | number>) => {
  let s = D[l][k] ?? D.en[k] ?? k;
  for (const x in p) s = s.replaceAll(`{${x}}`, String(p[x]));
  return s;
};
export const num = (l: Lang, n: number) => n.toLocaleString(l === 'ar' ? 'ar-EG' : 'en-US');
export const year = (l: Lang, n: number) => n.toLocaleString(l === 'ar' ? 'ar-EG' : 'en-US', { useGrouping: false });
