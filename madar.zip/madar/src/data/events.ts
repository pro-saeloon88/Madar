import type { Character, Choice, Effects, GameEvent, Stat } from '../engine/types.ts';
type S = Partial<Record<Stat, number>>;
const ch = (id: string, stats: S = {}, x: Omit<Effects, 'stats'> = {}): Choice => ({ id, effects: { stats, ...x } });
const ev = (id: string, minAge: number, maxAge: number, weight: number, choices: Choice[], x: Partial<GameEvent> = {}): GameEvent => ({ id, minAge, maxAge, weight, choices, ...x });
const sibling = (p: Character) => p.family.some((n) => n.role === 'sibling' && n.alive);
const oldParent = (p: Character) => p.family.some((n) => n.role !== 'sibling' && n.alive && n.age >= 65);
// Text lives in src/i18n/events.en.ts / events.ar.ts as [title, body, choice1, choice2], in the order of the choices below.
export const EVENTS: GameEvent[] = [
  // ---- childhood ----
  ev('firstSteps', 1, 2, 4, [ch('go', { fitness: 2, discipline: 1, health: -1 }), ch('crawl', { happiness: 1 })], { once: true }),
  ev('firstWords', 1, 3, 4, [ch('babble', { social: 3, happiness: 1 }), ch('listen', { intelligence: 3 })], { once: true }),
  ev('tantrum', 2, 5, 3, [ch('calm', { discipline: 2, happiness: -1 }), ch('scream', { happiness: 2, discipline: -2 }, { closeness: -3 })]),
  ev('kindergarten', 4, 6, 5, [ch('brave', { social: 4, discipline: 2 }), ch('cling', { social: -1 }, { closeness: 3 })], { once: true }),
  ev('playgroundFall', 3, 11, 3, [ch('tell', { health: -2 }, { closeness: 3 }), ch('hide', { health: -5, discipline: 1 })]),
  ev('pet', 5, 14, 2, [ch('keep', { happiness: 5, wealth: -2 }, { closeness: 2 }), ch('leave', { discipline: 1, happiness: -2 })], { once: true }),
  ev('sibling', 4, 16, 3, [ch('share', { social: 2 }, { closeness: 5 }), ch('grab', { happiness: 2 }, { closeness: -5 })], { when: sibling }),
  ev('schoolBully', 6, 14, 3, [ch('tell', { discipline: 3, social: 2 }), ch('fight', { fitness: 2, reputation: -3, health: -5, happiness: -2 }, { flags: ['fighter'] })]),
  ev('schoolPlay', 7, 13, 2, [ch('audition', { social: 4, reputation: 2 }), ch('backstage', { discipline: 3, intelligence: 1 })]),
  ev('holiday', 6, 16, 2, [ch('visit', { happiness: 3, wealth: -1 }, { closeness: 5 }), ch('games', { happiness: 4, fitness: -3, intelligence: 1 })]),
  ev('spellingBee', 8, 12, 2, [ch('enter', { intelligence: 4, discipline: 2, reputation: 2, happiness: -1 }), ch('skip', { happiness: 1 })], { boost: { t_ambitious: 2 } }),
  ev('examSeason', 8, 17, 3, [ch('study', { intelligence: 5, discipline: 3, happiness: -2 }), ch('play', { social: 4, happiness: 3, intelligence: -1 })]),
  ev('moneyWorries', 6, 16, 3, [ch('help', { discipline: 3, happiness: -2 }, { closeness: 4 }), ch('ignore', { happiness: 1 }, { closeness: -1 })], { when: (p) => p.stats.wealth <= 35 }),
  ev('tutor', 8, 16, 3, [ch('accept', { intelligence: 4, happiness: -1, wealth: -1 }), ch('refuse', { happiness: 2, discipline: -1 })], { when: (p) => p.stats.wealth >= 65 }),
  // ---- teenage years ----
  ev('firstCrush', 12, 17, 4, [ch('confess', { social: 3, happiness: 2, reputation: -1 }), ch('hide', { happiness: -2, discipline: 1 })], { once: true }),
  ev('peerPressure', 13, 18, 3, [ch('go', { social: 3, discipline: -3, intelligence: -1 }, { flags: ['skipped_class'] }), ch('no', { discipline: 3, social: -1 })], { boost: { t_adventurous: 1.5 } }),
  ev('sportsTryout', 12, 18, 2, [ch('try', { fitness: 4, social: 2, health: -1 }), ch('skip', { happiness: 1, fitness: -1 })], { boost: { t_adventurous: 2, t_lazy: 0.4 } }),
  ev('partTimeJob', 15, 19, 3, [ch('accept', { wealth: 6, discipline: 3, happiness: -2 }), ch('decline', { happiness: 2 })], { once: true }),
  ev('principal', 14, 19, 5, [ch('confess', { discipline: 2, reputation: -2 }), ch('lie', { reputation: -4 }, { flags: ['liar'] })], { once: true, needs: ['skipped_class'] }),
  ev('toughReputation', 12, 25, 4, [ch('walk', { discipline: 4, reputation: 2 }), ch('fight', { fitness: 2, health: -6, reputation: -3 })], { once: true, needs: ['fighter'] }),
  ev('curfew', 13, 18, 3, [ch('obey', { happiness: -2 }, { closeness: 3 }), ch('sneak', { happiness: 3, discipline: -2 }, { closeness: -5 })]),
  ev('driving', 16, 20, 3, [ch('careful', { discipline: 3, wealth: -1 }), ch('race', { happiness: 3, health: -3 }, { flags: ['reckless'] })], { once: true }),
  ev('graduationParty', 17, 19, 4, [ch('party', { happiness: 5, social: 2, wealth: -2 }), ch('rest', { health: 2, happiness: 1 })], { once: true }),
  // ---- adult life ----
  ev('lostWallet', 12, 80, 2, [ch('return', { reputation: 5, happiness: 3 }), ch('keep', { wealth: 8, reputation: -6 }, { flags: ['kept_wallet'] })]),
  ev('walletGuilt', 14, 90, 4, [ch('donate', { reputation: 3, wealth: -6, happiness: 4 }), ch('push', { happiness: -3 })], { once: true, needs: ['kept_wallet'] }),
  ev('gym', 18, 60, 2, [ch('join', { fitness: 5, health: 3, wealth: -2 }), ch('skip', { wealth: 1 })], { boost: { t_ambitious: 1.5, t_lazy: 0.5 } }),
  ev('unexpectedBill', 20, 65, 3, [ch('pay', { wealth: -8, discipline: 1 }), ch('ask', { wealth: -2 }, { closeness: -3 })]),
  ev('windfall', 20, 70, 1, [ch('save', { wealth: 10, discipline: 2 }), ch('treat', { wealth: 4, happiness: 6 })]),
  ev('oldFriend', 20, 70, 2, [ch('meet', { social: 4, happiness: 4, wealth: -1 }), ch('ignore', { social: -2, happiness: -1 })]),
  ev('roadAccident', 18, 65, 2, [ch('doctor', { health: -5, wealth: -3 }), ch('walk', { health: -12 })], { boost: { reckless: 2, t_adventurous: 1.5 } }),
  ev('burnout', 22, 60, 2, [ch('rest', { happiness: 4, health: 2, wealth: -2 }), ch('push', { wealth: 3, health: -4, discipline: 1 })]),
  ev('wedding', 22, 60, 2, [ch('attend', { happiness: 3, social: 3, wealth: -2 }), ch('decline', { social: -1, wealth: 1 })], { boost: { t_shy: 0.5 } }),
  ev('neighbor', 20, 85, 2, [ch('help', { reputation: 3, happiness: 2 }), ch('walk', { reputation: -1 })], { boost: { t_kind: 2 } }),
  ev('healthScare', 30, 75, 2, [ch('checkup', { health: 5, wealth: -2 }), ch('ignore', { health: -6, happiness: -2 })]),
  ev('familyDinner', 4, 90, 2, [ch('join', { happiness: 3 }, { closeness: 6 }), ch('skip', {}, { closeness: -5 })]),
  ev('tripOffer', 20, 70, 1, [ch('go', { happiness: 6, wealth: -5, social: 2 }), ch('stay', { discipline: 1, wealth: 1 })], { boost: { t_adventurous: 2 } }),
  ev('parentIll', 28, 70, 3, [ch('care', { wealth: -3, happiness: -2 }, { closeness: 8 }), ch('distance', { happiness: 1 }, { closeness: -6 })], { when: oldParent }),
  ev('midlife', 40, 55, 4, [ch('hobby', { happiness: 5, fitness: 2, wealth: -2 }), ch('stay', { discipline: 3, happiness: -1 })], { once: true }),
  ev('illness', 1, 85, 3, [ch('rest', { health: 4, wealth: -2 }), ch('ignore', { health: -8, discipline: 2 })]),
  // ---- later life ----
  ev('gardening', 60, 90, 2, [ch('plant', { happiness: 4, fitness: 2, health: 1 }), ch('no', { happiness: -1 })]),
  ev('memoryLane', 65, 95, 2, [ch('share', { happiness: 3 }, { closeness: 5 }), ch('keep', { happiness: 1 })]),
  ev('fallAtHome', 65, 95, 3, [ch('doctor', { health: -3, wealth: -3 }), ch('shrug', { health: -10 })]),
  ev('walks', 60, 90, 2, [ch('follow', { health: 4, fitness: 3 }), ch('ignore', { health: -3 })]),
  ev('lonely', 62, 95, 2, [ch('call', { social: 4, happiness: 4 }), ch('withdraw', { happiness: -4, social: -2 })], { when: (p) => p.stats.social < 45 }),
  ev('will', 70, 95, 3, [ch('write', { discipline: 2, wealth: -1, happiness: 2 }), ch('postpone', { happiness: -1 })], { once: true }),
];
