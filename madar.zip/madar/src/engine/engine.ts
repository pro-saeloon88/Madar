import { EVENTS } from '../data/events.ts';
import { next } from './rng.ts';
import { expectedFitness, expectedHealth, hazard } from './mortality.ts';
import { SAVE_VERSION, STATS } from './types.ts';
import type { Character, Effects, Stat } from './types.ts';

export const COUNTRIES = ['EG', 'SA', 'US'];
export const CLASSES: Record<string, number> = { poor: 20, middle: 50, rich: 80 };
type Fx = Partial<Record<Stat, number>>;
const TRAIT_FX: Record<string, Fx> = { kind: { social: 10, reputation: 5 }, ambitious: { discipline: 10, happiness: -5 }, shy: { social: -10, intelligence: 5 },
  adventurous: { fitness: 8, discipline: -3 }, lazy: { discipline: -10, happiness: 5 }, hotheaded: { fitness: 5, reputation: -5 } };
const BUILD_FX: Record<string, Fx> = { slim: { fitness: -3, appearance: 3 }, average: {}, athletic: { fitness: 12, appearance: 3 } };
const LOOK_FX: Record<string, Fx> = { plain: { appearance: -12 }, pleasant: {}, striking: { appearance: 15 } };

const clamp = (n: number) => Math.max(0, Math.min(100, n));
export const roll = (c: Character) => { const [v, s] = next(c.rng); c.rng = s; return v; };
const rr = (c: Character, a: number, b: number) => a + Math.floor(roll(c) * (b - a + 1));
const log = (c: Character, key: string, p?: Record<string, string | number>) => { c.log.push({ age: c.age, key, p }); };
const bump = (c: Character, fx: Fx) => { for (const s of STATS) if (fx[s]) c.stats[s] = clamp(c.stats[s] + fx[s]!); };

export interface NewChar { first: string; last: string; female: boolean; country: string; cls: string; dob: string; traits: string[]; build: string; look: string }

export function createCharacter(o: NewChar, seed = Date.now() >>> 0): Character {
  const c: Character = { v: SAVE_VERSION, id: String(seed), first: o.first.trim(), last: o.last.trim(), female: o.female, country: o.country,
    dob: o.dob, birthYear: Number(o.dob.slice(0, 4)) || new Date().getFullYear(), traits: o.traits.slice(0, 2), build: o.build, look: o.look,
    age: 0, alive: true, stats: {} as Record<Stat, number>, frailty: 1, flags: [o.cls, ...o.traits.slice(0, 2).map((x) => 't_' + x)],
    seen: [], recent: [], family: [], log: [], pending: null, rng: seed };
  for (const s of STATS) c.stats[s] = rr(c, 30, 70);
  Object.assign(c.stats, { health: rr(c, 70, 100), happiness: 80, reputation: 50, wealth: CLASSES[o.cls] ?? 50 });
  for (const x of c.traits) bump(c, TRAIT_FX[x] ?? {});
  bump(c, BUILD_FX[o.build] ?? {}); bump(c, LOOK_FX[o.look] ?? {});
  // hidden individual frailty: lognormal, median 1 (Box–Muller)
  c.frailty = Math.exp(0.25 * Math.sqrt(-2 * Math.log(1 - roll(c))) * Math.cos(2 * Math.PI * roll(c)));
  const npc = (role: 'mother' | 'father' | 'sibling', age: number) => c.family.push({ id: role + c.family.length, role, age, closeness: rr(c, 50, 90), alive: true });
  npc('mother', rr(c, 22, 38)); npc('father', rr(c, 24, 42));
  if (roll(c) < 0.5) npc('sibling', rr(c, 1, 10));
  log(c, 'log.born');
  return c;
}

function apply(c: Character, e: Effects) {
  bump(c, e.stats ?? {});
  e.flags?.forEach((f) => { if (!c.flags.includes(f)) c.flags.push(f); });
  if (e.closeness) c.family.forEach((n) => { if (n.alive) n.closeness = clamp(n.closeness + e.closeness!); });
}

export function eligibleEvents(c: Character) {
  return EVENTS.filter((e) => c.age >= e.minAge && c.age <= e.maxAge && !(e.once && c.seen.includes(e.id))
    && (e.needs ?? []).every((f) => c.flags.includes(f)) && !(e.blocks ?? []).some((f) => c.flags.includes(f))
    && (!e.countries || e.countries.includes(c.country)) && (!e.when || e.when(c)));
}

export function ageUp(c0: Character): Character {
  if (!c0.alive || c0.pending) return c0;
  const c = structuredClone(c0);
  // 1. Will this person survive the coming year?
  if (roll(c) < hazard(c.age, c.stats.health, c.frailty)) { c.alive = false; log(c, 'log.died'); return c; }
  c.age++;
  // 2. Family ages (same mortality curve, average health)
  for (const n of c.family) if (n.alive) {
    if (roll(c) < hazard(n.age, expectedHealth(n.age), 1)) { n.alive = false; c.stats.happiness = clamp(c.stats.happiness - 15); log(c, 'log.npcDied', { role: n.role }); }
    else n.age++;
  }
  // 3. Health, fitness and mood drift toward what is normal for the age
  const x = c.age;
  c.stats.health = clamp(c.stats.health + (expectedHealth(x) - c.stats.health) * 0.12 + (c.stats.fitness - expectedFitness(x)) / 60 + (roll(c) - 0.5) * 4);
  c.stats.fitness = clamp(c.stats.fitness + (expectedFitness(x) - c.stats.fitness) * 0.08 + (roll(c) - 0.5) * 2);
  c.stats.happiness = clamp(c.stats.happiness + (65 - c.stats.happiness) * 0.1);
  // 4. Maybe an event: context filter -> skip recent ones -> weighted by traits and past choices
  const ok = eligibleEvents(c);
  let pool = ok.filter((e) => !c.recent.includes(e.id));
  if (!pool.length) pool = ok;
  if (pool.length && roll(c) < 0.7) {
    const w = (e: (typeof pool)[number]) => e.weight * Object.entries(e.boost ?? {}).reduce((m, [f, k]) => (c.flags.includes(f) ? m * k : m), 1);
    let r = roll(c) * pool.reduce((a, e) => a + w(e), 0);
    const ev = pool.find((e) => (r -= w(e)) < 0) ?? pool[0];
    c.pending = ev.id; c.recent = [...c.recent, ev.id].slice(-6);
    if (ev.once) c.seen.push(ev.id);
  }
  return c;
}

export function choose(c0: Character, choiceId: string): Character {
  const ev = EVENTS.find((e) => e.id === c0.pending);
  const ch = ev?.choices.find((x) => x.id === choiceId);
  if (!ev || !ch) return c0;
  const c = structuredClone(c0);
  apply(c, ch.effects); log(c, `ev.${ev.id}.${ch.id}`); c.pending = null;
  return c;
}
