// Gompertz–Makeham mortality: h(x) = infant + accident + B·e^(C·x).
// B and C were fitted to two reference points of a modern life table (about 1% yearly death risk at 60 and
// about 16% at 90). It is a game model, not demographic data. Individuals differ through a hidden `frailty`
// multiplier and through health relative to what is normal for their age.
const B = 3.9e-5, C = 0.0924;
export const expectedHealth = (age: number) => Math.max(15, 88 - Math.max(0, age - 30) * 0.6);
export const expectedFitness = (age: number) => Math.max(15, 60 - Math.max(0, age - 35) * 0.5);
export const baseHazard = (x: number) =>
  (x < 1 ? 0.005 : x < 5 ? 0.0003 : 0) + 0.0003 + (x >= 15 && x < 35 ? 0.0006 : 0) + B * Math.exp(C * x);
/** Chance of dying during the year that starts at age x. */
export const hazard = (x: number, health: number, frailty: number) => {
  const m = Math.min(4, Math.max(0.35, Math.exp((expectedHealth(x) - health) / 30)));
  return Math.min(1, baseHazard(x) * frailty * m);
};
