export const SAVE_VERSION = 2;
export const STATS = ['health', 'happiness', 'intelligence', 'appearance', 'fitness', 'discipline', 'social', 'reputation', 'wealth'] as const;
export type Stat = (typeof STATS)[number];
export const TRAITS = ['kind', 'ambitious', 'shy', 'adventurous', 'lazy', 'hotheaded'] as const;
export const BUILDS = ['slim', 'average', 'athletic'] as const;
export const LOOKS = ['plain', 'pleasant', 'striking'] as const;
export interface Effects { stats?: Partial<Record<Stat, number>>; flags?: string[]; closeness?: number }
export interface Choice { id: string; effects: Effects }
export interface GameEvent {
  id: string; minAge: number; maxAge: number; weight: number; once?: boolean;
  needs?: string[]; blocks?: string[]; countries?: string[];
  when?: (c: Character) => boolean;        // extra context rule (family, wealth, social...)
  boost?: Record<string, number>;          // flag -> weight multiplier (traits, past choices)
  choices: Choice[];
}
export interface Npc { id: string; role: 'mother' | 'father' | 'sibling'; age: number; closeness: number; alive: boolean }
export interface LogEntry { age: number; key: string; p?: Record<string, string | number> }
export interface Character {
  v: number; id: string; first: string; last: string; female: boolean; country: string;
  dob: string; birthYear: number; traits: string[]; build: string; look: string;
  age: number; alive: boolean; stats: Record<Stat, number>; frailty: number;
  flags: string[]; seen: string[]; recent: string[];
  family: Npc[]; log: LogEntry[]; pending: string | null; rng: number;
}
