import { SAVE_VERSION, STATS } from '../engine/types.ts';
import type { Character } from '../engine/types.ts';
export type SlotState = { c: Character; recovered: boolean } | 'corrupt' | null;

const open = () => new Promise<IDBDatabase>((res, rej) => {
  const r = indexedDB.open('madar', 1);
  r.onupgradeneeded = () => r.result.createObjectStore('saves');
  r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
});
const tx = async <T>(mode: IDBTransactionMode, f: (s: IDBObjectStore) => IDBRequest<T>) => {
  const d = await open();
  try { return await new Promise<T>((res, rej) => { const q = f(d.transaction('saves', mode).objectStore('saves')); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); }
  finally { d.close(); }
};
const get = (k: string) => tx<unknown>('readonly', (s) => s.get(k));
const put = (k: string, v: unknown) => tx('readwrite', (s) => s.put(v, k));

/** Validates a stored object and upgrades older save versions. Returns null when it is not a usable save. */
export function migrate(raw: unknown): Character | null {
  const c = raw as any;
  if (!c || typeof c !== 'object' || (c.v !== 1 && c.v !== 2)) return null;
  if (typeof c.age !== 'number' || typeof c.first !== 'string' || !Array.isArray(c.family) || !Array.isArray(c.log) || !c.stats) return null;
  if (!STATS.every((s) => typeof c.stats[s] === 'number')) return null;
  return { dob: '', traits: [], build: 'average', look: 'pleasant', frailty: 1, recent: [], seen: [], flags: [], pending: null, ...c, v: SAVE_VERSION } as Character;
}

// Every save first copies the previous valid save to a backup. A damaged slot is restored from that backup;
// the damaged bytes are kept under "bad<n>" instead of being erased. If both copies are damaged the slot is reported, never wiped.
export async function loadSlot(n: number): Promise<SlotState> {
  try {
    const raw = await get('slot' + n); const c = migrate(raw);
    if (c) return { c, recovered: false };
    const b = migrate(await get('bak' + n));
    if (b) { if (raw !== undefined) await put('bad' + n, raw); await put('slot' + n, b); return { c: b, recovered: true }; }
    return raw === undefined ? null : 'corrupt';
  } catch { return null; }
}
export async function saveSlot(c: Character, n: number): Promise<boolean> {
  try {
    if (!migrate(c)) return false;
    const old = migrate(await get('slot' + n));
    if (old) await put('bak' + n, old);
    await put('slot' + n, c);
    return true;
  } catch (e) { console.error('save failed', e); return false; }
}
export async function deleteSlot(n: number) {
  for (const k of ['slot', 'bak', 'bad']) await tx('readwrite', (s) => s.delete(k + n));
}
