import { useEffect, useRef, useState } from 'react';
import { t, num, year, type Lang } from './i18n/index.ts';
import { COUNTRIES, CLASSES, createCharacter, ageUp, choose } from './engine/engine.ts';
import { EVENTS } from './data/events.ts';
import { STATS, TRAITS, BUILDS, LOOKS } from './engine/types.ts';
import type { Character } from './engine/types.ts';
import { loadSlot, saveSlot, deleteSlot, type SlotState } from './storage/db.ts';

type Pair = [string, string];
const today = () => new Date().toISOString().slice(0, 10);

function Create({ lang, onDone, onBack }: { lang: Lang; onDone: (c: Character) => void; onBack: () => void }) {
  const T = (k: string) => t(lang, k);
  const [f, setF] = useState({ first: '', last: '', female: false, country: 'EG', cls: 'middle', dob: today(), traits: [] as string[], build: 'average', look: 'pleasant' });
  const seg = (items: Pair[], val: string, set: (v: string) => void) => (
    <div className="seg">{items.map(([v, l]) => <button key={v} className={v === val ? 'on' : ''} onClick={() => set(v)}>{l}</button>)}</div>);
  const pairs = (keys: readonly string[], p: string): Pair[] => keys.map((x): Pair => [x, T(p + x)]);
  const toggle = (x: string) => setF({ ...f, traits: f.traits.includes(x) ? f.traits.filter((y) => y !== x) : f.traits.length < 2 ? [...f.traits, x] : f.traits });
  const valid = f.first.trim() && f.last.trim() && f.dob >= '1900-01-01' && f.dob <= today();
  return (
    <div className="card">
      <h2>{T('cr.title')}</h2>
      <label>{T('cr.first')}<input id="first" value={f.first} onChange={(e) => setF({ ...f, first: e.target.value })} /></label>
      <label>{T('cr.last')}<input id="last" value={f.last} onChange={(e) => setF({ ...f, last: e.target.value })} /></label>
      <label>{T('cr.dob')}<input id="dob" type="date" min="1900-01-01" max={today()} value={f.dob} onChange={(e) => setF({ ...f, dob: e.target.value })} /></label>
      <label>{T('cr.gender')}</label>
      {seg([['m', T('cr.male')], ['f', T('cr.female')]], f.female ? 'f' : 'm', (v) => setF({ ...f, female: v === 'f' }))}
      <label>{T('cr.country')}</label>
      {seg(pairs(COUNTRIES, 'c.'), f.country, (v) => setF({ ...f, country: v }))}
      <label>{T('cr.class')}</label>
      {seg(pairs(Object.keys(CLASSES), 'cr.'), f.cls, (v) => setF({ ...f, cls: v }))}
      <label>{T('cr.traits')}</label>
      <div className="seg wrap">{TRAITS.map((x) => <button key={x} className={f.traits.includes(x) ? 'on' : ''} onClick={() => toggle(x)}>{T('trait.' + x)}</button>)}</div>
      <label>{T('cr.build')}</label>
      {seg(pairs(BUILDS, 'build.'), f.build, (v) => setF({ ...f, build: v }))}
      <label>{T('cr.look')}</label>
      {seg(pairs(LOOKS, 'look.'), f.look, (v) => setF({ ...f, look: v }))}
      <button id="start" className="btn" disabled={!valid} onClick={() => onDone(createCharacter(f))}>{T('cr.start')}</button>
      <button className="ghost" onClick={onBack}>{T('cr.back')}</button>
    </div>);
}

export default function App() {
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem('lang') as Lang) || 'ar');
  const [slots, setSlots] = useState<SlotState[]>([null, null, null]);
  const [slot, setSlot] = useState(0);
  const [c, setC] = useState<Character | null>(null);
  const [screen, setScreen] = useState<'menu' | 'create' | 'life'>('menu');
  const [toast, setToast] = useState('');
  const tm = useRef<number>(0);
  const T = (k: string, p?: Record<string, string | number>) => t(lang, k, p);
  useEffect(() => { document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'; localStorage.setItem('lang', lang); }, [lang]);
  useEffect(() => { Promise.all([1, 2, 3].map((n) => loadSlot(n))).then(setSlots); }, []);
  const say = (m: string) => { setToast(m); window.clearTimeout(tm.current); tm.current = window.setTimeout(() => setToast(''), 1800); };
  const commit = (n: Character) => { setC(n); setSlots((s) => s.map((x, i) => (i === slot ? { c: n, recovered: false } : x))); saveSlot(n, slot + 1).then((ok) => { if (!ok) say(T('life.saveFail')); }); };
  const manualSave = async () => { if (c) say(T((await saveSlot(c, slot + 1)) ? 'life.saved' : 'life.saveFail')); };
  const remove = async (i: number) => { if (window.confirm(T('menu.confirmDelete'))) { await deleteSlot(i + 1); setSlots((s) => s.map((x, j) => (j === i ? null : x))); } };
  const ev = c?.pending ? EVENTS.find((e) => e.id === c.pending) : undefined;
  const fmt = (e: Character['log'][number]) => T(e.key, e.p?.role ? { role: T('role.' + e.p.role) } : e.p);
  const bornOn = (d: string) => (d ? new Date(d + 'T00:00:00').toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-GB', { dateStyle: 'long' }) : '');
  return (
    <div className="app">
      <div className="top"><button id="lang" className="ghost" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}>{T('menu.lang')}</button></div>
      {screen === 'menu' && <>
        <h1 className="logo">{T('app.name')}</h1><p className="tag">{T('app.tag')}</p>
        {slots.map((s, i) => (
          <div key={i} className="slotwrap">
            <button className="slot" disabled={s === 'corrupt'} onClick={() => { setSlot(i); if (s && s !== 'corrupt') { setC(s.c); setScreen('life'); } else setScreen('create'); }}>
              <b>{T('menu.slot', { n: num(lang, i + 1) })}</b>
              <span>{s === 'corrupt' ? T('menu.damaged') : s ? `${s.c.first} ${s.c.last} · ${T('life.age', { n: num(lang, s.c.age) })}${s.c.alive ? '' : ' ✝'}${s.recovered ? ' · ' + T('menu.recovered') : ''}` : T('menu.new')}</span>
            </button>
            {s && <button className="ghost del" aria-label={T('menu.delete')} title={T('menu.delete')} onClick={() => remove(i)}>🗑</button>}
          </div>))}
      </>}
      {screen === 'create' && <Create lang={lang} onBack={() => setScreen('menu')} onDone={(n) => { commit(n); setScreen('life'); }} />}
      {screen === 'life' && c && <>
        <div className="card stats">
          <h2>{c.first} {c.last}</h2>
          <p className="tag">{T('life.age', { n: num(lang, c.age) })} · {year(lang, c.birthYear + c.age)} · {T('c.' + c.country)}</p>
          {c.dob && <p className="tag small">{T('life.born', { d: bornOn(c.dob) })}</p>}
          {STATS.map((s) => (
            <div key={s} className="row"><span>{T('s.' + s)}</span><div className="bar"><i style={{ width: c.stats[s] + '%' }} /></div><b>{num(lang, Math.round(c.stats[s]))}</b></div>))}
        </div>
        {ev && <div className="card ev"><h3>{T(`ev.${ev.id}.t`)}</h3><p>{T(`ev.${ev.id}.b`)}</p>
          {ev.choices.map((x) => <button key={x.id} className="btn choice" onClick={() => commit(choose(c, x.id))}>{T(`ev.${ev.id}.${x.id}`)}</button>)}</div>}
        {!c.alive && <div className="card dead"><b>{T('life.dead')}</b></div>}
        <button id="ageup" className="btn" disabled={!!c.pending || !c.alive} onClick={() => commit(ageUp(c))}>{T('life.up')}</button>
        <div className="card"><h3>{T('life.family')}</h3>
          {c.family.map((n) => <div key={n.id} className="row"><span>{T('role.' + n.role)}</span><div className="bar"><i style={{ width: n.closeness + '%', opacity: n.alive ? 1 : 0.3 }} /></div><b>{num(lang, n.age)}</b></div>)}</div>
        <div className="card"><h3>{T('life.log')}</h3>
          {[...c.log].reverse().slice(0, 15).map((e, i) => <p key={i} className="lg"><b>{num(lang, e.age)}</b> {fmt(e)}</p>)}</div>
        <div className="two"><button id="save" className="ghost" onClick={manualSave}>{T('life.save')}</button><button id="menu" className="ghost" onClick={() => setScreen('menu')}>{T('life.menu')}</button></div>
      </>}
      {toast && <div className="toast" role="status">{toast}</div>}
    </div>);
}
