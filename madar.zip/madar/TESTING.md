# Testing record — v0.2.0
Environment: Node 22, headless Chromium (Playwright) with a 390×844 touch viewport, React 19.2, esbuild bundle. No internet, so `npm install` and Vite could not run.

## NOT performed
- `vite build` (Vite is not installed here). The project's real build is therefore **unverified**; I bundled the same source with esbuild instead.
- GitHub Actions run / GitHub Pages deployment (no access to your repository). The workflow file only passed a YAML parse.
- A real Android device or Android Chrome; the date picker and `confirm()` dialog on a phone are untested (Playwright auto-accepted dialogs).
- `tsc` against the real React types (not installed). `tsc` against a stub of them passed except 3 "implicit any" notes on `onChange` handlers that come from the stub. Everything outside App.tsx was type-checked normally.
- PWA/service worker (not built).

## Performed — `npm run check` (500 simulated lives + rules)
OK. 45 events, all 45 reached, none repeated when `once`, stats stay in 0–100, same seed gives the same life, no event picked that its rules forbid, EN and AR text complete for every key and every event choice, poor child gets money-worries and not tutor.

## Performed — `npm run sim` (10,000 lives, random choices, no player skill)
| | Pure curve (no events) | Full game |
|---|---|---|
| Mean death age | 75.9 | 74.8 |
| Median | 79 | 79 |
| Min / max | 0 / 106 | 0 / 111 |
| Reach 40 / 60 / 80 / 90 | 95.9 / 87.8 / 49.9 / 16.9 % | 94.7 / 86.0 / 47.3 / 16.8 % |
| Died aged 0–9, 10s, 20s, 30s, 40s | 1.0, 0.6, 1.1, 1.4, 2.6 % | 1.0, 0.9, 1.6, 1.8, 2.6 % |
| 50s, 60s, 70s, 80s, 90s, 100+ | 5.5, 12.8, 25.1, 33.0, 15.9, 1.0 % | 6.2, 13.9, 24.8, 30.5, 15.7, 1.1 % |
Events per life: 52.3. The full game sits about 1 year below the pure curve, so events are mildly harmful on average. Constants were set from two reference points (1% yearly risk at 60, 16% at 90), not tuned to a target mean. Compared with my rough, unchecked memory of modern life tables (about 97% reach 40, 90% reach 60, 55–60% reach 80), the model is somewhat harsher in the middle years; I left it as is.

## Performed — browser tests (`scripts/e2e.cjs`, 36/36 passed, see e2e-results.txt)
Served from a `/madar/` sub-path. Covers: menu and 3 slots; Arabic default with RTL and switch to English LTR; creation validation (empty names, future date, max 2 traits); stats from creation choices; age-up; event lock; choice effects and log; 25+ years of play; death; language switch without losing progress; autosave and reload restore; 3 independent slots; manual save and the IndexedDB record; backup restore from a corrupted slot (damaged bytes kept, slot healed); both copies corrupted (slot flagged, not wiped); delete cancel/confirm; a v1 save migrating to v2; zero JavaScript errors.
`scripts/smoke-standalone.cjs`: the single-file build opened from `file://` — create, age 4 years, reload, save present, 0 errors (PASS).
