import { createCharacter, ageUp, choose } from '../src/engine/engine.ts';
import { EVENTS } from '../src/data/events.ts';
import { hazard, expectedHealth } from '../src/engine/mortality.ts';
import { next } from '../src/engine/rng.ts';
const N = 10000;
const stats = (a: number[]) => {
  const s = [...a].sort((x, y) => x - y); const n = s.length;
  const surv = (x: number) => +(100 * s.filter((v) => v >= x).length / n).toFixed(1);
  const dist: Record<string, number> = {};
  for (const v of s) { const k = v >= 100 ? '100+' : `${Math.floor(v / 10) * 10}-${Math.floor(v / 10) * 10 + 9}`; dist[k] = (dist[k] ?? 0) + 1; }
  return { n, mean: +(s.reduce((x, y) => x + y, 0) / n).toFixed(1), median: s[n >> 1], min: s[0], max: s[n - 1], infantDeaths: s.filter((v) => v === 0).length,
    survival_pct: { 40: surv(40), 60: surv(60), 80: surv(80), 90: surv(90) }, distribution_pct: Object.fromEntries(Object.entries(dist).map(([k, v]) => [k, +(100 * v / n).toFixed(1)])) };
};
// A. pure mortality curve: average health for age, frailty 1 (no events at all)
const curve: number[] = [];
let rs = 12345; const r = () => { const [v, s] = next(rs); rs = s; return v; };
for (let i = 0; i < N; i++) { let a = 0; while (r() >= hazard(a, expectedHealth(a), 1)) a++; curve.push(a); }
// B. the full game: random frailty, health drift, every event, random choices
const base = { first: 'A', last: 'B', female: false, country: 'EG', dob: '2000-01-01', traits: [], build: 'average', look: 'pleasant' };
const game: number[] = []; let evs = 0;
for (let i = 1; i <= N; i++) {
  let c = createCharacter({ ...base, female: i % 2 === 0, cls: ['poor', 'middle', 'rich'][i % 3] }, i * 7919);
  while (c.alive) { c = ageUp(c); if (c.pending) { evs++; const e = EVENTS.find((x) => x.id === c.pending)!; c = choose(c, e.choices[Math.floor(r() * e.choices.length)].id); } }
  game.push(c.age);
}
console.log(JSON.stringify({ curveOnly: stats(curve), fullGame: stats(game), eventsPerLife: +(evs / N).toFixed(1) }, null, 1));
