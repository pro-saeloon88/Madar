// Browser test: serves dist-verify under /madar/ (like a GitHub Pages project site) and drives it with headless Chromium.
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const root = path.join(__dirname, '..', 'dist-verify');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
const srv = http.createServer((q, r) => { const f = path.join(root, q.url.replace(/^\/madar\/?/, '').split('?')[0] || 'index.html'); fs.readFile(fs.existsSync(f) && fs.statSync(f).isFile() ? f : path.join(root, 'index.html'), (e, d) => { r.writeHead(e ? 404 : 200, { 'content-type': mime[path.extname(f)] || 'text/html' }); r.end(d); }); });
const results = []; const ok = (name, cond, extra = '') => { results.push([cond ? 'PASS' : 'FAIL', name, extra]); console.log(cond ? 'PASS' : 'FAIL', name, extra); };
const dig = (s) => Number(String(s).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[^\d]/g, ''));
(async () => {
  await new Promise((r) => srv.listen(0, r)); const url = `http://127.0.0.1:${srv.address().port}/madar/`;
  const browser = await chromium.launch(); const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const page = await ctx.newPage(); const errors = [];
  page.on('pageerror', (e) => errors.push(String(e))); page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  let dialogs = 'accept'; page.on('dialog', (d) => (dialogs === 'accept' ? d.accept() : d.dismiss()));
  const idb = (op, key, val) => page.evaluate(([op, key, val]) => new Promise((res, rej) => { const o = indexedDB.open('madar', 1); o.onerror = () => rej(o.error);
    o.onsuccess = () => { const s = o.result.transaction('saves', op === 'get' ? 'readonly' : 'readwrite').objectStore('saves'); const q = op === 'get' ? s.get(key) : s.put(val, key); q.onsuccess = () => { o.result.close(); res(q.result); }; }; }), [op, key, val]);
  const text = (sel) => page.locator(sel).first().innerText();
  const slotsText = () => page.locator('.slot').allInnerTexts();
  const stats = async () => (await page.locator('.stats .row b').allInnerTexts()).map(dig);
  const widths = () => page.locator('.bar i').evaluateAll((els) => els.map((e) => e.style.width + e.style.opacity));
  const settle = () => page.waitForTimeout(250);
  const play = async (n, pick = 0) => { for (let i = 0; i < n; i++) { if (await page.locator('.dead').count()) return; await page.click('#ageup'); if (await page.locator('.ev').count()) { await page.locator('.choice').nth(pick % 2).click(); } } await settle(); };
  const newLife = async (slot, first, last, extra = async () => {}) => { await page.locator('.slot').nth(slot).click(); await page.fill('#first', first); await page.fill('#last', last); await extra(); await page.click('#start'); await settle(); };

  // T1 menu, default language, RTL
  await page.goto(url); await page.waitForSelector('.slot');
  ok('T1 app loads from a /madar/ subpath, 3 slots shown', (await page.locator('.slot').count()) === 3);
  ok('T1 default language Arabic with RTL', (await page.getAttribute('html', 'dir')) === 'rtl' && (await slotsText())[0].includes('حياة جديدة'));
  await page.click('#lang');
  ok('T1 switch to English gives LTR', (await page.getAttribute('html', 'dir')) === 'ltr' && (await slotsText())[0].includes('New life'));

  // T2 character creation
  await page.locator('.slot').nth(0).click();
  ok('T2 start disabled with empty names', await page.locator('#start').isDisabled());
  await page.fill('#first', 'Sara'); await page.fill('#last', 'Nasser'); await page.fill('#dob', '2999-01-01');
  ok('T2 start disabled for a future date of birth', await page.locator('#start').isDisabled());
  await page.fill('#dob', '2000-05-17');
  for (const t of ['Kind', 'Shy', 'Ambitious']) await page.getByRole('button', { name: t, exact: true }).click();
  ok('T2 personality limited to 2 traits', (await page.locator('.seg.wrap button.on').count()) === 2);
  for (const t of ['Female', 'Saudi Arabia', 'Wealthy', 'Athletic', 'Striking']) await page.getByRole('button', { name: t, exact: true }).click();
  await page.click('#start'); await settle();
  const st0 = await stats();
  ok('T2 life screen shows full name (first + last)', (await text('.stats h2')) === 'Sara Nasser');
  const head = await text('.stats'); 
  ok('T2 age 0, birth year 2000, country, date of birth shown', /Age 0/.test(head) && head.includes('2000') && head.includes('Saudi Arabia') && head.includes('17 May 2000'), head.replace(/\n/g, ' | ').slice(0, 90));
  ok('T2 nine stats; wealthy start = 80; striking+athletic raise appearance', st0.length === 9 && st0[8] === 80 && st0[3] >= 48, JSON.stringify(st0));
  ok('T2 family has parents', (await page.locator('.card:not(.stats) .row').count()) >= 2);

  // T3 age progression, event choices, consequences
  let sawEvent = false, effectOk = false, lockOk = true, logOk = false;
  for (let i = 0; i < 40 && !sawEvent; i++) {
    await page.click('#ageup');
    if (await page.locator('.ev').count()) {
      sawEvent = true; lockOk = await page.locator('#ageup').isDisabled();
      const before = await widths(); const label = await page.locator('.choice').nth(0).innerText();
      await page.locator('.choice').nth(0).click(); await settle();
      effectOk = JSON.stringify(before) !== JSON.stringify(await widths());
      logOk = (await text('.lg')).includes(label) && !(await page.locator('#ageup').isDisabled());
    }
  }
  ok('T3 an event appeared during age progression', sawEvent);
  ok('T3 age-up is locked while an event waits for a choice', lockOk);
  ok('T3 choice changed stats/relationships and was logged, age-up unlocked', effectOk && logOk);
  const ageBefore = dig((await text('.stats .tag')).match(/Age (\d+)/)[1]);
  await play(25, 1); await play(0);
  const a30 = dig((await text('.stats .tag')).match(/Age (\d+)/)[1]);
  ok('T3 age advanced one year per click', a30 > ageBefore && a30 <= ageBefore + 25, `${ageBefore} -> ${a30}`);
  ok('T3 stats stay within 0..100', (await stats()).every((v) => v >= 0 && v <= 100));

  // T4 death
  let guard = 0; while (!(await page.locator('.dead').count()) && guard++ < 140) await play(1, guard);
  ok('T4 character eventually dies and the death card appears', (await page.locator('.dead').count()) === 1, `age ${(await text('.stats .tag')).match(/Age (\d+)/)[1]}`);
  ok('T4 age-up disabled after death, death in log', (await page.locator('#ageup').isDisabled()) && (await page.locator('.lg').allInnerTexts()).some((l) => l.includes('Your life ended.')));

  // T5 language switch keeps progress
  const nameEn = await text('.stats h2'), ageEn = dig((await text('.stats .tag')).match(/Age (\d+)/)[1]), statsEn = await stats(), logEn = await page.locator('.lg').count();
  await page.click('#lang');
  const tagAr = await text('.stats .tag');
  ok('T5 Arabic: RTL, Arabic UI, same character', (await page.getAttribute('html', 'dir')) === 'rtl' && (await text('.stats h2')) === nameEn && dig(tagAr.match(/[٠-٩]+/)[0]) === ageEn, tagAr.replace(/\n/g, ' '));
  ok('T5 stats and log unchanged after language switch', JSON.stringify(await stats()) === JSON.stringify(statsEn) && (await page.locator('.lg').count()) === logEn);
  ok('T5 Arabic digits and Arabic labels rendered', /[٠-٩]/.test(await text('.stats .row b')) && (await text('.stats .row span')) === 'الصحة');
  await page.click('#lang');

  // T6 autosave + reload restore
  await settle(); await page.click('#menu'); const lab1 = (await slotsText())[0];
  ok('T6 menu shows slot 1 with name, age and death mark', lab1.includes('Sara Nasser') && lab1.includes(`Age ${ageEn}`) && lab1.includes('✝'), lab1.replace(/\n/g, ' '));
  await page.reload(); await page.waitForSelector('.slot');
  ok('T6 after reload the save is still there and language persisted', (await slotsText())[0].includes('Sara Nasser') && (await page.getAttribute('html', 'dir')) === 'ltr');
  await page.locator('.slot').nth(0).click();
  ok('T6 continuing restores identical stats', JSON.stringify(await stats()) === JSON.stringify(statsEn));

  // T7 independent slots + autosave mid-life
  await page.click('#menu'); await newLife(1, 'Omar', 'Hassan'); await play(6); const omar = dig((await text('.stats .tag')).match(/Age (\d+)/)[1]);
  await page.click('#menu'); await newLife(2, 'Lina', 'Park', async () => { await page.getByRole('button', { name: 'United States' }).click(); await page.getByRole('button', { name: 'Struggling' }).click(); }); await play(3);
  await page.click('#menu'); await page.reload(); await page.waitForSelector('.slot'); const s = await slotsText();
  ok('T7 three independent saves survive reload', s[0].includes('Sara') && s[1].includes('Omar Hassan') && s[2].includes('Lina Park') && s[1].includes(`Age ${omar}`), s.join(' / ').replace(/\n/g, ' '));

  // T8 manual save
  await page.locator('.slot').nth(1).click(); await page.click('#save');
  ok('T8 manual save shows confirmation', (await page.locator('.toast').innerText()) === 'Saved');
  const stored = await idb('get', 'slot2'); ok('T8 IndexedDB holds the current character', stored && stored.first === 'Omar' && stored.last === 'Hassan' && stored.age === omar && stored.v === 2);

  // T9 corrupted save -> backup
  await play(2); const bak = await idb('get', 'bak2'); const cur = await idb('get', 'slot2');
  ok('T9 backup holds the previous save', bak && bak.first === 'Omar' && bak.age <= cur.age);
  await idb('put', 'slot2', { garbage: true }); await page.click('#menu'); await page.reload(); await page.waitForSelector('.slot');
  const rec = (await slotsText())[1];
  ok('T9 corrupted slot restored from backup and user is told', rec.includes('Omar Hassan') && rec.includes('restored from backup'), rec.replace(/\n/g, ' '));
  ok('T9 damaged bytes kept, slot healed', (await idb('get', 'bad2')).garbage === true && (await idb('get', 'slot2')).first === 'Omar');
  await page.reload(); await page.waitForSelector('.slot'); ok('T9 next load is clean', !(await slotsText())[1].includes('restored'));
  await idb('put', 'slot3', 'junk'); await idb('put', 'bak3', { also: 'junk' }); await page.reload(); await page.waitForSelector('.slot');
  ok('T9 both copies damaged: slot flagged, not wiped, not clickable', (await slotsText())[2].includes('Damaged save') && (await page.locator('.slot').nth(2).isDisabled()) && (await idb('get', 'slot3')) === 'junk');

  // T10 deletion
  dialogs = 'dismiss'; await page.locator('.del').nth(2).click(); await settle();
  ok('T10 cancelling delete keeps the save', (await idb('get', 'slot3')) === 'junk' && (await slotsText())[2].includes('Damaged'));
  dialogs = 'accept'; await page.locator('.del').nth(2).click(); await settle();
  ok('T10 confirmed delete removes the slot and its backup', (await slotsText())[2].includes('New life') && (await idb('get', 'slot3')) === undefined && (await idb('get', 'bak3')) === undefined);
  await page.locator('.del').nth(0).click(); await settle();
  ok('T10 deleting a normal save works', (await slotsText())[0].includes('New life') && (await idb('get', 'slot1')) === undefined);

  // T11 older (v1) save is migrated
  const v1 = { v: 1, id: '1', first: 'Old', last: 'Timer', female: false, country: 'EG', birthYear: 2001, age: 9, alive: true, flags: ['middle'], seen: [], last_: '', family: [{ id: 'mother0', role: 'mother', age: 35, closeness: 70, alive: true }], log: [], pending: null, rng: 99,
    stats: { health: 80, happiness: 70, intelligence: 50, appearance: 50, fitness: 50, discipline: 50, social: 50, reputation: 50, wealth: 50 } };
  await idb('put', 'slot1', v1); await page.reload(); await page.waitForSelector('.slot'); await page.locator('.slot').nth(0).click(); await play(5);
  ok('T11 v1 save loads, plays on and is stored as v2', (await text('.stats h2')) === 'Old Timer' && (await idb('get', 'slot1')).v === 2);
  ok('T12 no JavaScript errors during the whole run', errors.length === 0, errors.slice(0, 3).join(' || '));
  const f = results.filter((r) => r[0] === 'FAIL').length; console.log(`\n${results.length - f}/${results.length} passed`);
  fs.writeFileSync(path.join(__dirname, '..', 'e2e-results.txt'), results.map((r) => r.join('  ')).join('\n') + `\n${results.length - f}/${results.length} passed\n`);
  await browser.close(); srv.close(); process.exit(f ? 1 : 0);
})().catch((e) => { console.error('HARNESS ERROR', e); process.exit(2); });
