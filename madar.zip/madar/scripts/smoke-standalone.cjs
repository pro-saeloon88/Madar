// Opens the single-file build from file:// (how it would open from a phone's file manager) and checks play + persistence.
const path = require('path'); const { chromium } = require('playwright');
(async () => {
  const f = 'file://' + path.join(__dirname, '..', 'dist-verify', 'madar-standalone.html'); const errs = [];
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true }); const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(String(e))); p.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
  await p.goto(f); await p.waitForSelector('.slot'); await p.locator('.slot').first().click();
  await p.fill('#first', 'Mona'); await p.fill('#last', 'Said'); await p.click('#start');
  for (let i = 0; i < 4; i++) { await p.click('#ageup'); if (await p.locator('.ev').count()) await p.locator('.choice').first().click(); }
  await p.waitForTimeout(300); await p.reload(); await p.waitForSelector('.slot');
  const label = (await p.locator('.slot').first().innerText()).replace(/\n/g, ' ');
  console.log(/Mona Said/.test(label) && errs.length === 0 ? 'PASS' : 'FAIL', 'standalone file:// play + reload persistence |', label, '| errors:', errs.length);
  await b.close(); process.exit(/Mona Said/.test(label) && !errs.length ? 0 : 1);
})();
