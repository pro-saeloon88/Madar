import { createCharacter, ageUp, choose, eligibleEvents } from '../src/engine/engine.ts';
import { EVENTS } from '../src/data/events.ts';
import { STATS } from '../src/engine/types.ts';
import { D } from '../src/i18n/index.ts';
let bad = 0; const fail = (m: string) => { if (bad++ < 30) console.log('FAIL', m); };
// 1. localization coverage
for (const k of Object.keys(D.en)) if (!D.ar[k]) fail('missing ar: ' + k);
for (const k of Object.keys(D.ar)) if (!D.en[k]) fail('missing en: ' + k);
for (const e of EVENTS) for (const k of [`ev.${e.id}.t`, `ev.${e.id}.b`, ...e.choices.map((c) => `ev.${e.id}.${c.id}`)]) if (!D.en[k] || !D.ar[k]) fail('event text: ' + k);
if (EVENTS.length < 40) fail('fewer than 40 events');
if (new Set(EVENTS.map((e) => e.id)).size !== EVENTS.length) fail('duplicate event id');
// 2. simulate lives with random choices
const base = { first: 'Sara', last: 'Nasser', female: true, country: 'EG', dob: '2000-05-17', traits: ['kind', 'shy'], build: 'average', look: 'pleasant' };
const live = (seed: number) => {
  let c = createCharacter({ ...base, cls: ['poor', 'middle', 'rich'][seed % 3] }, seed); let ev = 0, rep = 0; const seen: Record<string, number> = {};
  if (c.last !== 'Nasser' || c.first !== 'Sara') fail('name lost');
  while (c.alive) {
    c = ageUp(c);
    if (c.pending) {
      ev++; const e = EVENTS.find((x) => x.id === c.pending);
      if (!e) { fail('bad pending'); break; }
      if (!eligibleEvents({ ...c, pending: null }).some((x) => x.id === e.id) && !e.once) fail('ineligible event picked: ' + e.id);
      seen[e.id] = (seen[e.id] ?? 0) + 1; if (e.once && seen[e.id] > 1) fail('once-event repeated: ' + e.id);
      c = choose(c, e.choices[(seed + ev) % e.choices.length].id);
    }
    for (const s of STATS) if (!(c.stats[s] >= 0 && c.stats[s] <= 100)) fail(`stat ${s}=${c.stats[s]}`);
    if (c.age > 125) { fail('immortal'); break; }
  }
  return { c, ev, seen };
};
let ages = 0, evs = 0; const everSeen = new Set<string>();
for (let s = 1; s <= 500; s++) { const r = live(s); ages += r.c.age; evs += r.ev; Object.keys(r.seen).forEach((x) => everSeen.add(x)); }
if (JSON.stringify(live(7).c) !== JSON.stringify(live(7).c)) fail('not deterministic');
// 3. contextual rules
const kid = createCharacter({ ...base, cls: 'poor' }, 3); kid.age = 10;
if (!eligibleEvents(kid).some((e) => e.id === 'moneyWorries')) fail('poor child should see moneyWorries');
if (eligibleEvents(kid).some((e) => e.id === 'tutor')) fail('poor child must not see tutor');
if (eligibleEvents(kid).some((e) => e.id === 'principal')) fail('principal needs skipped_class');
kid.age = 70; if (eligibleEvents(kid).some((e) => e.minAge > 70)) fail('age filter');
console.log(bad ? `${bad} FAILURES` : 'OK', { events: EVENTS.length, lives: 500, avgDeathAge: +(ages / 500).toFixed(1), avgEventsPerLife: Math.round(evs / 500), eventsReached: `${everSeen.size}/${EVENTS.length}` });
if (everSeen.size < EVENTS.length) { console.log('never reached:', EVENTS.filter((e) => !everSeen.has(e.id)).map((e) => e.id).join(',')); bad++; }
if (bad) process.exit(1);
