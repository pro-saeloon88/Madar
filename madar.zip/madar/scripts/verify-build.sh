#!/bin/sh
# Offline verification bundle (esbuild). The real deploy uses `vite build`; this exists so the UI can be bundled and
# browser-tested where npm install is impossible. Output: dist-verify/ (relative paths, like Vite with base './').
set -e
cd "$(dirname "$0")/.."
rm -rf dist-verify && mkdir dist-verify
esbuild src/main.tsx --bundle --minify --format=esm --jsx=automatic --target=es2020 --define:process.env.NODE_ENV='"production"' --outfile=dist-verify/app.js --log-level=warning
sed 's#<script type="module" src="/src/main.tsx"></script>#<link rel="stylesheet" href="./app.css"><script type="module" src="./app.js"></script>#' index.html > dist-verify/index.html
ls -l dist-verify
esbuild src/main.tsx --bundle --minify --format=iife --jsx=automatic --target=es2020 --define:process.env.NODE_ENV='"production"' --outfile=dist-verify/app.iife.js --log-level=warning
python3 - <<'PY'
css = open('dist-verify/app.css').read(); js = open('dist-verify/app.iife.js').read().replace('</script', '<\\/script')
html = open('index.html').read().replace('<script type="module" src="/src/main.tsx"></script>', '')
html = html.replace('</head>', '<style>' + css + '</style></head>').replace('</body>', '<script>' + js + '</script></body>')
open('dist-verify/madar-standalone.html', 'w').write(html)
PY
ls -l dist-verify/madar-standalone.html
