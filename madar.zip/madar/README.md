# MADAR (مدار)
Your Life. Your Choices. Your Legacy. / حياتك. اختياراتك. إرثك.

## Play now (no install)
Open `madar-standalone.html` in Chrome. It is a single-file build of the same code, saves to the browser's IndexedDB, works offline.

## Run / deploy the real project
`npm install` → `npm run dev` (develop) · `npm run build` (production, Vite) · `npm run check` (engine + EN/AR tests) · `npm run sim` (10,000-life mortality report).
GitHub Pages: push to `main`, then Settings → Pages → Source: **GitHub Actions**. `base: './'` makes it work under any repo name.

## Status — Phase 1 (v0.2.0)
Done and tested: see TESTING.md (what was run, what was NOT run). Short version:
- Tested: engine, 45 events, EN/AR coverage, mortality (10,000 lives), full UI flow in headless Chromium on an esbuild production bundle.
- NOT yet verified: the Vite build, the GitHub Actions run, a real Android device, type-checking against the real React types.
- Not done in Phase 1: PWA install/service worker (offline works only after the first load, and only via the standalone file today).
Docs: GAME_DESIGN.md · ARCHITECTURE.md · ROADMAP.md · CHANGELOG.md · TESTING.md
