# MADAR — Roadmap
- **Phase 1 (current):** foundation. Remaining before it is closed: confirm the Vite build and GitHub Actions deploy on your repo; PWA manifest + service worker; country-specific events (the `countries` rule exists, no event uses it yet); follow-up for the `liar` flag; real-device test on Android.
- **Phase 2:** education, careers, relationships/marriage/children, finance.
- **Phase 3:** business, investments, health system, crime/legal, travel, NPC personalities.
- **Phase 4:** legacy, inheritance, playing as descendants, family history.
- **Phase 5:** achievements, challenges, more events, animations, performance, Capacitor packaging.
Rule: no phase starts until the previous one runs and its tests are recorded in TESTING.md.
