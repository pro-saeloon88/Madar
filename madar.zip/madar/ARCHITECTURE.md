# MADAR — Architecture

## Layers (dependencies point downward only)
1. **UI** (`src/App.tsx`, later `src/ui/*`) — React, no game rules, renders `Character` and calls engine functions.
2. **Engine** (`src/engine`) — pure functions `(Character) -> Character`. No DOM, no React, no I/O. Mortality lives in `mortality.ts`. Seeded RNG (`rng.ts`) lives inside the save, so lives are reproducible and testable.
3. **Data** (`src/data`) — events, later careers, countries, achievements as plain typed arrays. Adding content = adding data, not code.
4. **i18n** (`src/i18n`) — `en.ts` / `ar.ts` key tables. Gameplay code only emits keys (`ev.<id>.t`, `ev.<id>.<choice>`, `log.*`); event text is written as `[title, body, choice1, choice2]` and expanded into keys by `i18n/index.ts` (so i18n reads event ids from `data/`); `scripts/check.ts` fails if any key is missing in either language.
5. **Storage** (`src/storage`) — IndexedDB, 3 slots, versioned (`v`, migration 1→2), validated on load, previous save kept as backup before every overwrite; damaged slots restore from backup (damaged bytes kept as `bad<n>`) or are shown as damaged, never wiped.

## Event engine
`GameEvent { id, minAge, maxAge, weight, once, needs[], blocks[], countries[], when(c), boost{flag:×}, choices[{ id, effects{stats, flags, closeness} }] }`.
Each year: filter by conditions -> weighted pick (none of the last 6 events) -> player chooses -> effects apply -> flags change which events become eligible later (the hook for long-term consequences).

## Folder structure
```
src/engine/   types, rng, engine (create, ageUp, choose)
src/data/     events (more files per system later)
src/engine/mortality.ts
src/i18n/     index, en, ar
src/storage/  db
src/App.tsx, main.tsx, styles.css
scripts/  check.ts (engine + i18n tests), mortality.ts (10k lives), e2e.cjs + smoke-standalone.cjs (browser), verify-build.sh (offline esbuild bundle)
.github/workflows/    build + deploy to GitHub Pages
```
Planned: `engine/{education,career,finance,health,crime,legacy}.ts`, `data/{careers,countries,achievements}.ts`, `ui/` per screen.

## Milestone 1 — reached in 0.2.0
Menu with 3 slots, bilingual UI with live RTL/LTR switch, full character creation, 9 stats, age-up loop, 45 events, family, autosave + manual save + delete, death. Next: close Phase 1 gaps (see ROADMAP.md), then Education → Careers + Finance → Relationships.
